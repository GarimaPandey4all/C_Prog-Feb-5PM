#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[5];
    int i;

    printf("Enter values in an Array:\n");
    for(i = 0; i < 5; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("Values in an Array:\n");
    for(i = 0; i < 5; i++)
    {
        printf("%d  ", arr[i]);
    }

    return 0;
}
