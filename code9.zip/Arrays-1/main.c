#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr[5]; // array declaration
    int i;

    //Traditional Way of Initialization
    int arr1[5] = {10, 20, 30, 40, 50}; //declare and initialize

    //Compile time Initialization
    int arr2[] = {1, 2, 3, 4, 5};

    printf("Value of Array:%d\n", arr2[2]);

    printf("Values in Arr2 are:\n");
    for(i = 0; i < 5; i++)
    {
        printf("%d  ", arr2[i]);
    }

    return 0;
}
