#include <stdio.h>
#include <stdlib.h>

/*
    Loops: Repeatation or Repeat or Iteration

    Types of Loops:
    1. For Loop
    2. While Loop
    3. Do-While Loop

    for loop:

    for(initialization; condition; increment/decrement)
    {
        //Block of Statements
    }

    while Loop:

    initialization

    while(condition)
    {
        //Block of Statements
        increment / decrement
    }

    do - while loop:

    initialization

    do
    {
        //Block of Statements
        increment / decrement
    }while(condition);
*/

int main()
{
    int n, i;

    printf("Enter any number to print the table:");
    scanf("%d", &n);

    for(i = 1; i <= 10; i++)
    {
        printf("%d * %d = %d\n", n, i, n * i);
    }

    return 0;
}
