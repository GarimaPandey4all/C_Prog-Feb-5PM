#include <stdio.h>
#include <stdlib.h>

/*
    Function has Four Types:

    1. Function without arguments and without return value
    2. Function with arguments and without return value
    3. Function without arguments and with return value
    4. Function with arguments and with return value

*/

//2. Function with arguments and without return value

//void Add(int, int);

void main()
{
    //Function Calling
    Add(10, 20);// 10, 20: Actual Arguments
    Add(30, 50);

}

void Add(int a, int b) // Function Parameters / Formal Arguments
{
    printf("Addition is: %d\n", (a + b));
}
