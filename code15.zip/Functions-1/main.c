#include <stdio.h>
#include <stdlib.h>

/*
    Function has Four Types:

    1. Function without arguments and without return value
    2. Function with arguments and without return value
    3. Function without arguments and with return value
    4. Function with arguments and with return value

*/

//1. Function without arguments and without return value

//Function Declaration or optional
void Add(); //void - empty or null

void main()
{
    //Function Calling
    Add();
    Add();
    Add();
    Add();

    //return 0;
}

//Function Definition or Initialization
void Add() // Function Prototype: return type, function name , function arguments
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));
}
