#include <stdio.h>
#include <stdlib.h>

/*
    String Built-in Functions

    1. String Length
    2. String Copy
    3. String Concatenation/Joining
    4. String Compare
    5. String Uppercase
    6. String Lowercase

    String Compare:

    str1 , str2

    str1 == str2 = 0
    str1 > str2 = negative difference ex: a > b
    str1 < str2 = positive difference

*/

int main()
{
    char name[10];
    char str1[10];
    char str2[10];

    printf("Enter your name:");
    gets(name);

    printf("Your name length is: %d\n", strlen(name));

    printf("Enter any string:");
    gets(str1);

    printf("Enter any string:");
    gets(str2);

    printf("String-1 is copying in String-2: %s\n", strcpy(str2, str1));
//    printf("Str-2 is: %s", str2);
//
//    printf("Manali is copying in String-2: %s\n", strcpy(str2, "Manali"));

    //printf("String - Concatenation: %s\n", strcat(str1, str2));

    if(strcmp(str1, str2) == 0)
    {
        printf("Both the Strings are same\n");
    }
    else
    {
        printf("Strings are not same\n");
    }

    printf("Uppercase is: %s\n", strupr(str1));
    printf("Lowercase is: %s\n", strlwr(str2));


    return 0;
}
