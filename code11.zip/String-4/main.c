#include <stdio.h>
#include <stdlib.h>

int main()
{
    char arr[] = "welcome";
    int i;

    for(i = 0; arr[i] != '\0'; i++)
    {
        arr[i] = arr[i] - 32;
    }

    printf("Uppercase is: %s\n", arr);

    for(i = 0; arr[i] != '\0'; i++)
    {
        arr[i] = arr[i] + 32;
    }

    printf("Lowercase is: %s", arr);

    return 0;
}
