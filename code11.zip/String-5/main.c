#include <stdio.h>
#include <stdlib.h>

int main()
{
    char arr[] = "How are you";
    int i, word = 1;

    for(i = 0; arr[i] != '\0'; i++)
    {
        if(arr[i] == ' ')
        {
            word++;
        }
    }

    printf("Total words in a string are: %d", word);

    return 0;
}
