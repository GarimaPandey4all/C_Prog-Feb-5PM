#include <stdio.h>
#include <stdlib.h>

// variable - vary or change
// constant - fixed or no change

int main()
{
    int a = 10;
    const float pi = 3.14f;
    const int b = 20;

    //b = 30; //error

    a = a + 20;

    //pi = 3.56f;

    printf("%d", a);

    return 0;
}
