#include <stdio.h>
#include <stdlib.h>

int main()
{
    int choice;
    int a, b, temp;

    while(1) // infinite times
    //for(;;)
    {
    printf("\n\nPress 1. X-OR Bitwise");
    printf("\nPress 2. Swap Numbers with third variable");
    printf("\nPress 3. Swap Numbers without third variable");
    printf("\nPress 4. AND Logical");
    printf("\nPress 5. Exit.");
    printf("\n\nEnter your choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("X -OR is: %d", (a ^ b));
        break;

    case 2:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Before Swapping the value of a=%d and b=%d\n", a, b);

        temp = a;
        a = b;
        b = temp;

        printf("After Swapping the value of a=%d and b=%d\n", a, b);
        break;

    case 3:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        /*
        printf("Before Swapping the value of a=%d and b=%d\n", a, b);

        //first-way
        a = a + b;
        b = a - b;
        a = a - b;

        printf("After Swapping the value of a=%d and b=%d\n", a, b);
        */

        /*
        printf("Before Swapping the value of a=%d and b=%d\n", a, b);

        //second-way
        a = a * b;
        b = a / b;
        a = a / b;

        printf("After Swapping the value of a=%d and b=%d\n", a, b);
    */

        printf("Before Swapping the value of a=%d and b=%d\n", a, b);

        //third-way
        a = a ^ b;
        b = a ^ b;
        a = a ^ b;

        printf("After Swapping the value of a=%d and b=%d\n", a, b);

        break;

    case 4:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("AND Logical is: %d\n", (a && b));

        break;

    case 5:
        exit(0);

    default:
        printf("Invalid Choice");

    } // switch-end
    }

    //printf("Outside the switch block");

    return 0;
}
