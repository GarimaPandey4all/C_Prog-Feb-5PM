#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    if(a > b)
    {
        printf("A is Greater\n");
    }
    else // optional
    {
        printf("B is Greater\n");
    }

    printf("Outside the if-else");

    return 0;
}
