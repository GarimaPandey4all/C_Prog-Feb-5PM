#include <stdio.h>
#include <stdlib.h>

/*
    Ternary / Conditional Operator: '? :'

    Ternary - 3

    Syntax:

    (Condition) ? True : False

    (Expression - 1) ? Expression - 2 : Expression - 3

*/

int main()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    //Shorthand of If-Else or If-Else if- Else
    (a > b) ? printf("A is Greater") : printf("B is Greater");

    return 0;
}
