#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10;
    char ch = 'N';
    float f = 45.67f;
    double d = 67.89;

    printf("a is: %d\n", a); // \n - new line
    printf("ch is: %c\n", ch);
    printf("f is: %.2f\n", f);
    printf("f is: %lf\n", d);

    printf("size of Int is: %d\n", sizeof(a));
    printf("size of Int is: %d\n", sizeof(int));
    printf("size of Char is: %d\n", sizeof(char));
    printf("size of Float is: %d\n", sizeof(float));
    printf("size of Double is: %d\n", sizeof(double));

    return 0;
}
