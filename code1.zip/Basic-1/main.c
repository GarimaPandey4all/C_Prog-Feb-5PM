#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b; // variable declaration

    printf("Enter any value for a and b:");
    scanf("%d%d", &a, &b); // %d - format specifier , & - address of operator

    //scanf - Read User Input

    printf("Value of a=%d and b=%d", a, b);

    return 0;
}
