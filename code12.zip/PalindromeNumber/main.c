#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, temp, r, sum = 0;

    printf("Enter any number:");
    scanf("%d", &n);

    temp = n;

    while(n > 0)
    {
        //n = 121
        r = n%10; // r = 1, 2, 1
        sum = sum * 10 + r; // sum = 1, 12, 121
        n = n / 10; // n = 12 , 1 , 0
    }

    n = temp;

    if(n == sum)
    {
        printf("Palindrome Number");
    }
    else
    {
        printf("Not the Palindrome Number");
    }

    return 0;
}
