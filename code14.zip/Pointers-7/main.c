#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 10;
    char ch = 'B';
    float j = 3.45f;

    void *ptr; // void pointer

    ptr = &i;
    printf("I is: %d\n", *(int *)ptr);

    ptr = &ch;
    printf("Ch is: %c\n", *(char *)ptr);

    ptr = &j;
    printf("J is: %f", *(float *)ptr);

    return 0;
}
