#include <stdio.h>
#include <stdlib.h>

union Date
{
    int day;
    int month;
    int year;
}date1, *pdate;

//union Date date1;

int main()
{
    //union Date date1;

    pdate = &date1;

    pdate->day = 2;

    printf("Day=%d\n", pdate->day);

    (*pdate).month = 2;

    printf("Month=%d\n", (*pdate).month);

    (*pdate).year = 2021;

    printf("Year=%d\n", (*pdate).year);

    return 0;
}
