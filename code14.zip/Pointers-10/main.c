#include <stdio.h>
#include <stdlib.h>

struct Date
{
    int day;
    int month;
    int year;
}date1, *pdate;

//struct Date date1;

int main()
{
    //struct Date date1;

    pdate = &date1;

    pdate->day = 2;
    (*pdate).month = 2;
    pdate->year = 2021;

    printf("Day=%d , Month=%d, and Year=%d\n", pdate->day, pdate->month, (*pdate).year);

    return 0;
}
