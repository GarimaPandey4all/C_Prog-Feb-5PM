#include <stdio.h>
#include <stdlib.h>

/*

    pointer to a constant: value can't be changed
    Constant Pointer: address can't be changed

*/

int main()
{
    const int value = 10;
    int number = 20;
    //const int *pvalue = &value; // pointer to a constant
    //int *const pvalue = &value; // Constant Pointer

    const int *const pvalue = &value; // pointer to a constant and constant pointer

    //*pvalue = 30; // error

    //pvalue = &number; // error

    //value = 30; // error

    return 0;
}
