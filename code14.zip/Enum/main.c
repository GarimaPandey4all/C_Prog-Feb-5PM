#include <stdio.h>
#include <stdlib.h>

int main()
{
    //enum: Enumeration: Group of Constants

    enum Week {Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday};

    enum Week Today = Tuesday;

    printf("Today is: %d", Today);

    return 0;
}
