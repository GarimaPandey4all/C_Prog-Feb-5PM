#include <stdio.h>
#include <stdlib.h>

struct Date
{
    int day;
    int month;
    int year;
}date1, date2;

//struct Date date1;

int main()
{
    //struct Date date1;

    date1.day = 2;
    date1.month = 2;
    date1.year = 2021;

    printf("Day=%d , Month=%d, and Year=%d\n", date1.day, date1.month, date1.year);

    date2.day = 1;
    date2.month = 2;
    date2.year = 2021;

    printf("Day=%d , Month=%d, and Year=%d\n", date2.day, date2.month, date2.year);


    return 0;
}
