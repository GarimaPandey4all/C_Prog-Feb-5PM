#include <stdio.h>
#include <stdlib.h>

/*
    base address: initial address of the array or name of the array
                            &arr[0]                     arr

*/

int main()
{
    int arr[5];
    int i;

    printf("enter values in array:\n");
    for(i = 0; i < 5; i++)
    {
        scanf("%d", arr + i); // 100
    }

    printf("values in Array are:\n");
    for(i = 0; i < 5; i++)
    {
        printf("%d  ", *(arr + i));
    }

    return 0;
}
