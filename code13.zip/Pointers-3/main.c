#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 100;

    int *pvalue = NULL;

    int result = 0;

    pvalue = &value;

    result = *pvalue + 20;

    printf("Result is: %d", result);

    return 0;
}
