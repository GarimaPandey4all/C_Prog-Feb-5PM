#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 0;

    int *pvalue = &value;

    printf("enter any value:");
    scanf("%d", pvalue);

    printf("Value is: %d", *pvalue);

    return 0;
}
