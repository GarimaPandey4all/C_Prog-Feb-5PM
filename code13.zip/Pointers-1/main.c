#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 10;

    int *pvalue = &value;

    printf("Value is: %d\n", value); // value = 10

    printf("Value is: %d\n", *pvalue); // dereference operator = value = 10

    printf("Value is: %d\n", pvalue); // address of value

    printf("Value is: %d\n", &pvalue); // address of pointer variable

    return 0;
}
