#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10; // assignment/initialization/definition

    a += 10; //a = a + 10;

    //a %= 20; //a = a % 20;

    printf("a is: %d", a);

    return 0;
}
