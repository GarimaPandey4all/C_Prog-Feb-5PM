#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("AND Logical is: %d\n", (a > 10 && b < 10));
    printf("OR Logical to is: %d\n", (a > 10 || b < 10));
    printf("Not Logical is: %d\n", !(a > 10 && b < 10));

    return 0;
}
