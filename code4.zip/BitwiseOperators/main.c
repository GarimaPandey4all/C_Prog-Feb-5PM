#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("And Bitwise: %d\n", (a & b));
    printf("Or Bitwise to is: %d\n", (a | b));
    printf("X-OR Bitwise is: %d\n", (a ^ b));
    printf("Left Shift: %d\n", (a << 2));
    printf("Right Shift: %d\n", (a >> 2));
    printf("1's Complement: %d\n", (~a));

    return 0;
}
